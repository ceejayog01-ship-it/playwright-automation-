# Required frozen strategy data

The recovered ZIP supplied for this update did not contain the original frozen `strategies.json` or `edges.json`.

These files define the actual 51 BEST strategies and their parent-edge mappings. They are source research artifacts and must be restored from the original verified project/export. Do not replace them with made-up or empty strategy definitions.

Expected files:
- `strategies.json` — the original 51 BEST strategy rows
- `edges.json` — the original parent-edge metadata

The market-cycle workflow now checks for both files before starting a cycle and exits with an explicit message if either is missing.
