#!/usr/bin/env bash
set -euo pipefail
exec "$(dirname "$0")/scripts/run_cycle.sh" "$@"
