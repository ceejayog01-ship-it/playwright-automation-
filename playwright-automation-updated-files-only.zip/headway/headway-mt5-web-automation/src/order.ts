import { Page } from 'playwright';
import * as fs from 'fs';
import * as path from 'path';
import { Selectors } from '../config/selectors';
import { findFirstVisible, safeClick, screenshotOnFailure, sleep } from './utils';
import { Policy } from './policy';
import { readMargin, waitForQuote } from './quotes';

/**
 * Guarded DUMMY order: a tiny connectivity/execution test, separate from the strategy contract
 * (the strategy lifecycle stays simulated at 0.50 lots). Order of safety:
 *   1. guards (pure, unit-tested) run BEFORE the browser is even launched;
 *   2. default is a DRY RUN that opens the ticket, sets volume, screenshots, and closes it WITHOUT clicking Buy/Sell;
 *   3. executing needs --execute AND ALLOW_ORDERS=yes (and, on a real account, REAL_ORDER_CONFIRM=REAL-<last 4 of login>);
 *   4. it refuses to click unless the account Margin and a live quote are readable (so the result can be verified);
 *   5. Buy/Sell is clicked at most ONCE per run: there is no retry that could double-fire.
 * The ticket/close selectors are UNVERIFIED against the live terminal; run the dry run first and adjust config/selectors.ts.
 */
export const MAX_DUMMY_LOTS = 0.10;

export class OrderGuardError extends Error {}

export interface OrderRequest { symbol: string; side: 'buy' | 'sell'; lots: number; execute: boolean; closeAfter: boolean; }
export interface OrderEnv { ALLOW_ORDERS?: string; REAL_ORDER_CONFIRM?: string; ORDER_SYMBOLS?: string; MT5_LOGIN?: string; }

export function assertOrderAllowed(policy: Policy, req: OrderRequest, env: OrderEnv): void {
  const allowed = (env.ORDER_SYMBOLS || 'EURUSD').split(',').map(s => s.trim().toUpperCase()).filter(Boolean);
  if (!allowed.includes(req.symbol.toUpperCase())) throw new OrderGuardError(`symbol_not_allowed:${req.symbol}`);
  if (req.side !== 'buy' && req.side !== 'sell') throw new OrderGuardError('bad_side');
  if (!Number.isFinite(req.lots) || req.lots <= 0 || req.lots > MAX_DUMMY_LOTS + 1e-9) throw new OrderGuardError(`lots_out_of_range(0<lots<=${MAX_DUMMY_LOTS})`);
  if (Math.abs(req.lots * 100 - Math.round(req.lots * 100)) > 1e-9) throw new OrderGuardError('lots_not_multiple_of_0.01');
  if (req.closeAfter && !req.execute) throw new OrderGuardError('close_requires_execute');
  if (!req.execute) return;
  if (policy.mode !== 'demo') throw new OrderGuardError('automated_execution_demo_only');
  if (env.ALLOW_ORDERS !== 'yes') throw new OrderGuardError('orders_disabled:set ALLOW_ORDERS=yes');
}

interface Stage { name: string; ok: boolean; detail: string; }
export interface OrderReport {
  schema: 1; kind: 'DUMMY_ORDER'; account_mode: string; symbol: string; side: string; lots: number;
  execute: boolean; dry_run: boolean; close_requested: boolean; stages: Stage[];
  margin_before: number | null; margin_after_open: number | null; margin_after_close: number | null;
  opened_confirmed: boolean; closed_confirmed: boolean | null; outcome: string;
  started_at: string; finished_at: string; run_id: string;
}

const REJECT = /(rejected|invalid (volume|stops|price|request)|not enough money|no money|market (is )?closed|trade (is )?disabled|requote|off quotes)/i;
const EPS = 0.005;

async function anyText(page: Page): Promise<string> {
  const parts: string[] = [];
  for (const f of page.frames()) parts.push(await f.locator('body').innerText({ timeout: 2000 }).catch(() => ''));
  return parts.join('\n');
}

async function pollMargin(page: Page, test: (m: number) => boolean, ms: number): Promise<number | null> {
  const end = Date.now() + ms; let last: number | null = null;
  while (Date.now() < end) {
    last = await readMargin(page);
    if (last !== null && test(last)) return last;
    await sleep(1000);
  }
  return last;
}

async function openTicket(page: Page, symbol: string): Promise<boolean> {
  for (const f of page.frames()) {
    const row = f.getByText(symbol, { exact: true }).first();
    if (await row.isVisible({ timeout: 800 }).catch(() => false)) { await row.dblclick({ timeout: 5000 }).catch(() => {}); break; }
  }
  if (await findFirstVisible(page, Selectors.order.volumeInput, 6000)) return true;
  await page.keyboard.press('F9').catch(() => {});            // MT5 shortcut: new order
  return !!(await findFirstVisible(page, Selectors.order.volumeInput, 6000));
}

async function ticketHasSymbol(page: Page, symbol: string): Promise<boolean> {
  for (const f of page.frames()) {
    const values: string[] = await f.locator('input, select').evaluateAll(els => els.map(e => (e as HTMLInputElement).value || '')).catch(() => []);
    if (values.some(v => v.toUpperCase().includes(symbol.toUpperCase()))) return true;
  }
  return false;
}

export async function runDummyOrder(page: Page, policy: Policy, req: OrderRequest, outDir = path.join(process.cwd(), 'artifacts')): Promise<OrderReport> {
  const stages: Stage[] = [];
  const started = new Date().toISOString();
  const rep: OrderReport = {
    schema: 1, kind: 'DUMMY_ORDER', account_mode: policy.mode, symbol: req.symbol.toUpperCase(), side: req.side, lots: req.lots,
    execute: req.execute, dry_run: !req.execute, close_requested: req.closeAfter, stages,
    margin_before: null, margin_after_open: null, margin_after_close: null, opened_confirmed: false, closed_confirmed: null,
    outcome: 'not_started', started_at: started, finished_at: started, run_id: process.env.GITHUB_RUN_ID || 'local',
  };
  const st = (name: string, ok: boolean, detail = '') => { stages.push({ name, ok, detail }); console.log(`[order] ${ok ? 'OK  ' : 'FAIL'} ${name}${detail ? ' – ' + detail : ''}`); return ok; };
  const abort = (why: string) => { rep.outcome = `failed:${why}`; };

  try {
    rep.margin_before = await readMargin(page);
    if (!st('margin_readable', rep.margin_before !== null, String(rep.margin_before))) { if (req.execute) return abort('margin_unreadable'), rep; }
    const q = await waitForQuote(page, req.symbol, 20000);
    if (!st('live_quote', !!q, q ? `bid ${q.bid} ask ${q.ask}` : 'not found')) { if (req.execute) return abort('quote_unreadable'), rep; }

    if (!st('ticket_opened', await openTicket(page, req.symbol))) { await screenshotOnFailure(page, 'order-ticket-not-found'); return abort('ticket_not_opened'), rep; }
    const vol = await findFirstVisible(page, Selectors.order.volumeInput, 4000);
    if (!vol) { await screenshotOnFailure(page, 'order-volume-missing'); return abort('volume_input_missing'), rep; }
    await vol.fill(String(req.lots), { timeout: 5000 });
    const applied = Number(await vol.inputValue().catch(() => 'NaN'));
    if (!st('volume_applied', Math.abs(applied - req.lots) < 1e-9, `wanted ${req.lots}, field shows ${applied}`)) { await screenshotOnFailure(page, 'order-volume-not-applied'); return abort('volume_not_applied'), rep; }
    if (!st('symbol_in_ticket', await ticketHasSymbol(page, req.symbol))) { await screenshotOnFailure(page, 'order-wrong-symbol'); return abort('symbol_not_in_ticket'), rep; }
    await screenshotOnFailure(page, 'order-ticket-ready');

    if (!req.execute) {
      await page.keyboard.press('Escape').catch(() => {});
      const m = await readMargin(page);
      st('dry_run_no_position', m === null || rep.margin_before === null || Math.abs(m - rep.margin_before) < EPS, `margin ${m}`);
      rep.outcome = stages.every(s => s.ok) ? 'dry_run_ok' : 'failed:dry_run_checks';
      return rep;
    }

    // ---- the single click ----
    const clicked = await safeClick(page, req.side === 'buy' ? Selectors.order.buy : Selectors.order.sell, `${req.side.toUpperCase()} (dummy ${req.lots} lots)`, 8000);
    if (!st('side_clicked_once', clicked)) { await screenshotOnFailure(page, 'order-side-button-missing'); return abort('side_button_missing'), rep; }

    const before = rep.margin_before ?? 0;
    const end = Date.now() + 20000; let rejected = '';
    while (Date.now() < end && !rep.opened_confirmed && !rejected) {
      const m = await readMargin(page);
      if (m !== null && m > before + EPS) { rep.opened_confirmed = true; rep.margin_after_open = m; break; }
      const hit = (await anyText(page)).match(REJECT);
      if (hit) rejected = hit[0];
      await sleep(1000);
    }
    await screenshotOnFailure(page, 'order-after-click');
    if (rejected) { st('order_rejected', false, rejected); return abort(`order_rejected:${rejected}`), rep; }
    if (!st('position_confirmed_by_margin', rep.opened_confirmed, `before ${before} after ${rep.margin_after_open}`)) {
      rep.outcome = 'executed_unconfirmed';   // clicked, but not verifiable: CHECK THE ACCOUNT MANUALLY
      return rep;
    }
    rep.outcome = 'executed_confirmed';

    if (req.closeAfter) {
      await safeClick(page, Selectors.trading.tradeTab, 'Trade tab', 4000).catch(() => false);
      let closed = false;
      for (const f of page.frames()) {
        const rows = f.locator('tr, [role="row"]').filter({ hasText: new RegExp(`${req.symbol}.*${req.side}|${req.side}.*${req.symbol}`, 'i') });
        const n = await rows.count().catch(() => 0);
        if (n === 0) continue;
        if (n !== 1) { st('close_position_row', false, `${n} matching rows – refusing to guess`); break; }
        await rows.first().click({ button: 'right', timeout: 5000 }).catch(() => {});
        if (await safeClick(page, Selectors.order.closeMenuItem, 'Close position menu item', 5000)) {
          await safeClick(page, Selectors.order.closeConfirm, 'Close confirmation', 4000).catch(() => false);
          closed = true;
        }
        break;
      }
      if (closed) {
        rep.margin_after_close = await pollMargin(page, m => m <= before + EPS, 20000);
        rep.closed_confirmed = rep.margin_after_close !== null && rep.margin_after_close <= before + EPS;
        st('position_closed_by_margin', rep.closed_confirmed, `margin ${rep.margin_after_close}`);
      } else { rep.closed_confirmed = false; st('close_attempted', false, 'could not close via UI'); }
      await screenshotOnFailure(page, 'order-after-close');
      if (!rep.closed_confirmed) rep.outcome = 'executed_confirmed_close_failed';   // CLOSE THE DUMMY POSITION MANUALLY
    }
    return rep;
  } catch (e) {
    st('exception', false, String(e).slice(0, 200));
    await screenshotOnFailure(page, 'order-exception');
    if (rep.outcome === 'not_started') abort('exception');
    return rep;
  } finally {
    rep.finished_at = new Date().toISOString();
    try {
      fs.mkdirSync(outDir, { recursive: true });
      fs.writeFileSync(path.join(outDir, 'order_result.json'), JSON.stringify(rep, null, 2) + '\n');
    } catch { /* reporting must not mask the outcome */ }
  }
}

export function orderExitCode(outcome: string): number {
  if (outcome === 'dry_run_ok' || outcome === 'executed_confirmed') return 0;
  if (outcome === 'executed_confirmed_close_failed' || outcome === 'executed_unconfirmed') return 3;
  return 1;
}
